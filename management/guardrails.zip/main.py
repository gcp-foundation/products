def event_handler(event, context):
    print("Hello from guardrails")
